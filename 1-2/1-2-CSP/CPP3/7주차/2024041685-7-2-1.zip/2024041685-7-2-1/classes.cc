#include "classes.h"
#include <iostream>

void A::test() {
	std::cout << "A::test()" << std::endl;
}

void B::test() {
	std::cout << "B::test()" << std::endl;
}

void C::test() {
	std::cout << "C::test()" << std::endl;
}

